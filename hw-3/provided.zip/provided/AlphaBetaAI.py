import chess
from math import inf


class AlphaBetaAI():
    def __init__(self, depth):
        pass

    def choose_move(self, board):
        pass
